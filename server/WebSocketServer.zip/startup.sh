cd "$(dirname "$0")"
# export USE_TLS=true
# export PRIVATE_KEY=private-key.pem
# export CERTIFICATE=certificate.pem
# export PORT=3000
node server.js
